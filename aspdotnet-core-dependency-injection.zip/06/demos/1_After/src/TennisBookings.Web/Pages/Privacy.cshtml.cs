﻿using Microsoft.AspNetCore.Mvc.RazorPages;

namespace TennisBookings.Web.Pages
{
    public class PrivacyModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}