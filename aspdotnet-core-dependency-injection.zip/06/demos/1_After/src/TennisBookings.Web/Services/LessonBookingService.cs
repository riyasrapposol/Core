﻿
namespace TennisBookings.Web.Services
{
    public interface ILessonBookingService { }
    public class LessonBookingService : ILessonBookingService
    {
        // FUTURE
    }
}
