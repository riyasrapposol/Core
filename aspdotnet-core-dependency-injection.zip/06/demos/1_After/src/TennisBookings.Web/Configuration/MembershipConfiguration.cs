﻿namespace TennisBookings.Web.Configuration
{
    public class MembershipConfiguration
    {
        public decimal MonthlyMembershipFullPrice { get; set; }
    }
}