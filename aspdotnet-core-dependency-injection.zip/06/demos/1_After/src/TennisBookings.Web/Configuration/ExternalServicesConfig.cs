﻿namespace TennisBookings.Web.Configuration
{
    public class ExternalServicesConfig
    {
        public string WeatherApiUrl { get; set; }
    }
}
