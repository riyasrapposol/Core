﻿namespace TennisBookings.Web.Configuration
{
    public interface IFeaturesConfiguration
    {
        bool EnableWeatherForecast { get; set; }
    }
}
