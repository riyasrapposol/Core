﻿namespace TennisBookings.Web.Configuration
{
    public class FeaturesConfiguration : IFeaturesConfiguration
    {
        public bool EnableWeatherForecast { get; set; }
    }
}
