﻿namespace TennisBookings.Web.Services
{
    public interface IWeatherForecaster
    {
        WeatherResult GetCurrentWeather();
    }
}