﻿namespace TennisBookings.Web.External.Models
{
    public enum WeatherCondition
    {
        Sun,
        Rain
    }
}
