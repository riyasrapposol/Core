﻿
using TennisBookings.Web.External.Models;

namespace TennisBookings.Web.Services
{
    public class WeatherResult
    {
        public WeatherCondition WeatherCondition { get; set; }
    }
}
