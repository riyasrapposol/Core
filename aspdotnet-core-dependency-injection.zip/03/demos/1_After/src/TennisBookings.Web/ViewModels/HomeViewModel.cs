﻿
namespace TennisBookings.Web.ViewModels
{
    public class HomeViewModel
    {
        public string WeatherDescription { get; set; }
    }
}
