﻿
namespace TennisBookings.Web.Configuration
{
    public class FeaturesConfiguration
    {
        public bool EnabledWeatherForecast { get; set; }
    }
}
